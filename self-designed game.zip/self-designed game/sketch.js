var pcman,pcmanstartimg;
var gameState=0;
var topwall,bottomwall,leftwall,rightwall,walls;
var topimg, bottomimg, leftimg, rightimg;
var startButton;
var pcmanimg;
var o1img, o2img, o3img, o4img, o5img, o6img, o7img;
var obstacle1, obstacle2, obstacle3, obstacle4,obstacle5,obstacle6,obstacle7,obstacle8,obstacle9,obstacle10,obstacle11,obstacle12,obstacle13,obstacle14,obstacle15,obstacle16;

function preload()
{
  pcmanstartimg=loadImage("pcmanbg.png");
  topimg=loadImage("img/topside.png");
  bottomimg=loadImage("img/downside.png");
  leftimg=loadImage("img/leftside.png");
  rightimg=loadImage("img/rightside.png");

  pcmanimg=loadImage("img/pcman.png")
  o1img=loadImage("img/1.1.png");
  o2img=loadImage("img/1.2.png");
  o3img=loadImage("img/1.3.png");
  o4img=loadImage("img/1.4.png");
  o5img=loadImage("img/2.1.png");
  o6img=loadImage("img/2.2.png");
  o7img=loadImage("img/2.3.png");
}

function setup() {
  createCanvas(800,650);
  topwall=createSprite(400,25,800,20);
bottomwall=createSprite(400,615,800,20);
leftwall=createSprite(25,325,20,610);
rightwall=createSprite(772,325,20,610);
  walls=new Group();
  walls.add(topwall);
  walls.add(bottomwall);
  walls.add(leftwall);
  walls.add(rightwall);
topwall.addImage(topimg);
topwall.scale=3.6;
bottomwall.addImage(bottomimg);
bottomwall.scale=3.6;
leftwall.addImage(leftimg);
leftwall.scale=2.6;
rightwall.addImage(rightimg);
rightwall.scale=2.6;

obstacle1=createSprite(100,100,70,30);
//obstacle1.addImage(o1img);
//obstacle1.scale=2;
obstacle1.shapeColor="black";
obstacle2=createSprite(300,100,70,30);
// obstacle2.addImage(o2img);
// obstacle2.scale=2;
obstacle2.shapeColor="black";
obstacle3=createSprite(500,100,70,30);
// obstacle3.addImage(o3img);
// obstacle3.scale=2;
obstacle3.shapeColor="black";
obstacle4=createSprite(700,100,70,30);
// obstacle4.addImage(o4img);
// obstacle4.scale=2;
obstacle4.shapeColor="black";
obstacle5=createSprite(250,200,70,30);
// obstacle5.addImage(o1img);
// obstacle5.scale=2;
obstacle5.shapeColor="black";
obstacle6=createSprite(540,200,70,30);
// obstacle6.addImage(o2img);
// obstacle6.scale=2;
obstacle6.shapeColor="black";
obstacle7=createSprite(700,200,70,30);
// obstacle7.addImage(o3img);
// obstacle7.scale=2;
obstacle7.shapeColor="black";
obstacle8=createSprite(100,300,70,30);
// obstacle8.addImage(o4img);
// obstacle8.scale=2;
obstacle8.shapeColor="black";
obstacle9=createSprite(250,300,70,30);
// obstacle9.addImage(o1img);
// obstacle9.scale=2;
obstacle9.shapeColor="black";
obstacle10=createSprite(550,300,70,30);
// obstacle10.addImage(o2img);
// obstacle10.scale=2;
obstacle10.shapeColor="black";
obstacle11=createSprite(300,400,70,30);
// obstacle11.addImage(o3img);
// obstacle11.scale=2;
obstacle11.shapeColor="black";
obstacle12=createSprite(600,400,70,30);
// obstacle12.addImage(o4img);
// obstacle12.scale=2;
obstacle12.shapeColor="black";
obstacle13=createSprite(250,500,70,30);
// obstacle13.addImage(o1img);
// obstacle13.scale=2;
obstacle13.shapeColor="black";
obstacle14=createSprite(650,500,70,30);
// obstacle14.addImage(o2img);
// obstacle14.scale=2;
obstacle14.shapeColor="black";
obstacle15=createSprite(450,600,70,30);
// obstacle15.addImage(o3img);
// obstacle15.scale=2;
obstacle15.shapeColor="black";
obstacle16=createSprite(550,600,70,30);
// obstacle16.addImage(o4img);
// obstacle16.scale=2;
obstacle16.shapeColor="black";
walls.add(obstacle1);
walls.add(obstacle2);
walls.add(obstacle3);
walls.add(obstacle4);
walls.add(obstacle5);
walls.add(obstacle6);
walls.add(obstacle7);
walls.add(obstacle8);
walls.add(obstacle9);
walls.add(obstacle10);
walls.add(obstacle11);
walls.add(obstacle12);
walls.add(obstacle13);
walls.add(obstacle14);
walls.add(obstacle15);
walls.add(obstacle16);

startButton=createButton("START GAME");
startButton.position(350,500);
  pcman=createSprite(200,100,20,20);

}



function draw() {


  if (gameState==0)
  {
      background("#1230FB"); 
      textFont("tahoma");
      textSize(50);
      fill ("yellow");
    text("PAC-MAN GAME",200,350);
    image (pcmanstartimg, 500,240,250,200);
    startButton.mousePressed(
      function()
      {
        gameState=1;
        startButton.hide();
      
    }
  );
  }else if(gameState==1)
  {
    background("#AAD407");
    navigation();
    pcman.collide(walls);
    drawSprites();
  }



}
 function navigation()
 {
   if(keyDown("up"))
   {
    pcman.y=pcman.y-4;
   }
   if(keyDown("down"))
   {
    pcman.y=pcman.y+4;
   }
   if(keyDown("right"))
   {
    pcman.x=pcman.x+4;
   } 
   if(keyDown("left"))
   {
    pcman.x=pcman.x-4;
   } 
 }